DROP TABLE public.gapp_additional_req CASCADE;

DROP TABLE public.gapp_additional_req_detail CASCADE;

DROP TABLE public.gapp_application CASCADE;

DROP TABLE public.gapp_application_status CASCADE;

DROP TABLE public.gapp_department CASCADE;

DROP TABLE public.gapp_program CASCADE;

DROP TABLE public.gapp_university_degree CASCADE;

DROP TABLE public.gapp_user_type CASCADE;

DROP TABLE public.gapp_users CASCADE;

DROP TABLE public.gapp_users_gapp_user_type CASCADE;

DROP TABLE public.gapp_file CASCADE;

DROP SEQUENCE public.hibernate_sequence CASCADE;