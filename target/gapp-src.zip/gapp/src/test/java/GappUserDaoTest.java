/*package gapp.model.dao;

import gapp.model.GappUsers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;


@Test(groups = "GappUserDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class GappUserDaoTest  extends AbstractTransactionalTestNGSpringContextTests{

	@Autowired
	GappUserDao gappUserDao;
	
	@Test
	public void findUserType(){
		
		//assert gappUserDao.findUserType("admin@localhost.localdomain", "abcd").getUsertype().get(0).getType().equals("admin");
		assert gappUserDao.findUserType("admin@localhost.localdomain", "abcd").getId().equals(1);
	}
}
*/