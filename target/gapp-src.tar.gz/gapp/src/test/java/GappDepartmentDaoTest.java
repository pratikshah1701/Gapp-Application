/*package gapp.model.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

@Test(groups = "GappDepartmentDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class GappDepartmentDaoTest extends AbstractTransactionalTestNGSpringContextTests {
	
	
	
	@Autowired
	GappDepartmentDao departmentDao;
	
	
	public void getDepartments(){
		  assert departmentDao.getDepartments().size()==2;
	}

}
*/